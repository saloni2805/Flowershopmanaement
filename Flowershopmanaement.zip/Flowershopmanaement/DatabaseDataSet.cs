﻿namespace Flowershopmanaement {
    
    
    public partial class DatabaseDataSet {
    }
}
namespace Flowershopmanaement {
    
    
    public partial class DatabaseDataSet {
    }
}
namespace Flowershopmanaement {
    
    
    public partial class DatabaseDataSet {
    }
}

namespace Flowershopmanaement.DatabaseDataSetTableAdapters {
    
    
    public partial class PaymentsTableAdapter {
    }
}
